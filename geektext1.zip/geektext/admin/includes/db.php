<?php

	$con = mysqli_connect("localhost","root","","geek_text");

?>